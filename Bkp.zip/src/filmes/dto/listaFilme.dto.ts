export class ListaFilmeDTO{
    constructor(
        readonly id: string,
        readonly nome: string,
        readonly ano: string,
        readonly genero: string
        ){}
}